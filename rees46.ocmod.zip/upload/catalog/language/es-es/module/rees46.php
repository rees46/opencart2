<?php
// Text
$_['text_tax']                  = 'Ex impuestos:';
$_['text_more']                 = 'Más';
$_['text_type_interesting']     = 'También te puede interesar';
$_['text_type_also_bought']     = 'Frecuentemente Comprado Junto';
$_['text_type_similar']         = 'Productos Similares';
$_['text_type_popular']         = 'Lo más vendid';
$_['text_type_see_also']        = 'Recomendado para ti';
$_['text_type_recently_viewed'] = 'Visto Recientement';
$_['text_type_buying_now']      = 'Productos más vistos';
$_['text_type_search']          = 'Clientes que buscan este producto también compraron';
$_['text_type_supply']          = 'Pedido';
