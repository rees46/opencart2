<?php
// Text
$_['text_tax']                  = 'Imposto Ex:';
$_['text_more']                 = 'Mais';
$_['text_type_interesting']     = 'Você pode gostar';
$_['text_type_also_bought']     = 'Frequentemente comprados juntos';
$_['text_type_similar']         = 'Produtos Similares';
$_['text_type_popular']         = 'Produtos populares';
$_['text_type_see_also']        = 'Recomendado para você';
$_['text_type_recently_viewed'] = 'Você viu recentemente';
$_['text_type_buying_now']      = 'Produtos de tendências';
$_['text_type_search']          = 'Clientes que procuraram este item também compraram';
$_['text_type_supply']          = 'Compra regular';
