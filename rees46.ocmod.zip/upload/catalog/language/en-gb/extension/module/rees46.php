<?php
// Text
$_['text_tax']                  = 'Ex Tax:';
$_['text_more']                 = 'More';
$_['text_type_interesting']     = 'You May Also Like';
$_['text_type_also_bought']     = 'Frequently Bought Together';
$_['text_type_similar']         = 'Similar Products';
$_['text_type_popular']         = 'Popular Products';
$_['text_type_see_also']        = 'Recommended For You';
$_['text_type_recently_viewed'] = 'You Recently Viewed';
$_['text_type_buying_now']      = 'Trending Products';
$_['text_type_search']          = 'Customers Who Looked For This Item Also Bought';
$_['text_type_supply']          = 'Regular Purchase';
