<?php
// Text
$_['text_tax']                  = 'Exkl moms:';
$_['text_more']                 = 'Mer';
$_['text_type_interesting']     = 'Du kanske också gillar';
$_['text_type_also_bought']     = 'Ofta Köpt Tillsamman';
$_['text_type_similar']         = 'Liknande produkter';
$_['text_type_popular']         = 'Populära produkter';
$_['text_type_see_also']        = 'Rekommenderat för dig';
$_['text_type_recently_viewed'] = 'Du tittade nyligen på';
$_['text_type_buying_now']      = 'Populäraste produkter';
$_['text_type_search']          = 'Kunder som såg för denna produkt har även köpt';
$_['text_type_supply']          = 'Regelbunden Inköp';
