<?php
// Text
$_['text_tax']                  = 'Ex Tax:';
$_['text_more']                 = 'More';
$_['text_type_interesting']     = 'You may like it';
$_['text_type_also_bought']     = 'Also bought with this product';
$_['text_type_similar']         = 'Similar products';
$_['text_type_popular']         = 'Popular products';
$_['text_type_see_also']        = 'See also';
$_['text_type_recently_viewed'] = 'Recently viewed';
$_['text_type_buying_now']      = 'Right now bought';
$_['text_type_search']          = 'Customers who looked for this product also bought';