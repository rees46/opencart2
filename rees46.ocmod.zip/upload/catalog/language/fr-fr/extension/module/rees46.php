<?php
// Text
$_['text_tax']                  = 'Ex-impôts:';
$_['text_more']                 = 'Plus';
$_['text_type_interesting']     = 'Tu pourrais aussi aimer';
$_['text_type_also_bought']     = 'Produits fréquemment achetés ensemble';
$_['text_type_similar']         = 'Produits similaires';
$_['text_type_popular']         = 'Produits populaires';
$_['text_type_see_also']        = 'Recommandé pour vous';
$_['text_type_recently_viewed'] = 'Vous avez récemment visionné';
$_['text_type_buying_now']      = 'Produits Tendances';
$_['text_type_search']          = 'Les clients ayant acheté ce produit ont également acheté';
$_['text_type_supply']          = 'Achat régulier';
