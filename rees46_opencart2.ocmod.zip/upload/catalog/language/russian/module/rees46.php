<?php
// Text
$_['text_tax']                  = 'Без налога:';
$_['text_more']                 = 'Подробнее';
$_['text_type_interesting']     = 'Возможно, вам это понравится';
$_['text_type_also_bought']     = 'С этим товаром покупают';
$_['text_type_similar']         = 'Похожие товары';
$_['text_type_popular']         = 'Популярные товары';
$_['text_type_see_also']        = 'Посмотрите также';
$_['text_type_recently_viewed'] = 'Вы недавно смотрели';
$_['text_type_buying_now']      = 'Прямо сейчас покупают';
$_['text_type_search']          = 'Пользователи, искавшие этот товар, также купили';