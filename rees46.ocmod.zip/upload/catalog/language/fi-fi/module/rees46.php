<?php
// Text
$_['text_tax']                  = 'Ex Vero:';
$_['text_more']                 = 'Lisää';
$_['text_type_interesting']     = 'Saatat pitää myös';
$_['text_type_also_bought']     = 'Usein osti yhdessä';
$_['text_type_similar']         = 'Vastaavia tuotteita';
$_['text_type_popular']         = 'Suosituimmat tuotteet';
$_['text_type_see_also']        = 'Suositeltu sinulle';
$_['text_type_recently_viewed'] = 'Te Viimeksi katsottu';
$_['text_type_buying_now']      = 'Trendituotteista';
$_['text_type_search']          = 'Asiakkaat jotka etsivät Saatavana myös';
$_['text_type_supply']          = 'Säännöllinen ostosta';
