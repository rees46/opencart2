<?php
// Text
$_['text_tax']                  = 'Ex-Steuer:';
$_['text_more']                 = 'Mehr';
$_['text_type_interesting']     = 'Sie können auch mögen';
$_['text_type_also_bought']     = 'Wird oft zusammen gekauft';
$_['text_type_similar']         = 'Ähnliche Produkte';
$_['text_type_popular']         = 'Beliebte Produkte';
$_['text_type_see_also']        = 'Für dich empfohlen';
$_['text_type_recently_viewed'] = 'Du hast dir zuletzt angesehen';
$_['text_type_buying_now']      = 'Trending Produkte';
$_['text_type_search']          = 'Kunden, die diesen Artikel gesucht haben, wurden auch gekauft';
$_['text_type_supply']          = 'Regelmäßiger Kauf';
