<?php
// Text
$_['text_tax']                  = 'Tax Es:';
$_['text_more']                 = 'Più';
$_['text_type_interesting']     = 'Potrebbe piacerti anche';
$_['text_type_also_bought']     = 'Acquistati frequentemente insieme';
$_['text_type_similar']         = 'Prodotti Simili';
$_['text_type_popular']         = 'Prodotti popolari';
$_['text_type_see_also']        = 'Raccomandato per te';
$_['text_type_recently_viewed'] = 'Hai visto di recente';
$_['text_type_buying_now']      = 'Tendenza Prodotti';
$_['text_type_search']          = 'I clienti che hanno consultato Per questo prodotto hanno acquistato anche';
$_['text_type_supply']          = 'Acquisto regolare';
